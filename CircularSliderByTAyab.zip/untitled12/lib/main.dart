import 'package:flutter/material.dart';
import 'dart:math' as math;

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Circular Slider',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      debugShowCheckedModeBanner: false, // Remove debug banner
      home: CircularSliderPage(),
    );
  }
}

class CircularSliderPage extends StatefulWidget {
  @override
  _CircularSliderPageState createState() => _CircularSliderPageState();
}

class _CircularSliderPageState extends State<CircularSliderPage> {
  double _currentSliderValue = 0.5;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Circular Slider',
          style: TextStyle(fontSize: 24), // Increase font size
          textAlign: TextAlign.center,
        ),
        centerTitle: true,
      ),
      body: Center(
        child: Container(
          width: 200,
          height: 200,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Colors.blue, Colors.green],
            ),
            shape: BoxShape.circle,
          ),
          child: GestureDetector(
            onPanUpdate: (details) {
              double angle =
              math.atan2(details.localPosition.dy - 100, details.localPosition.dx - 100);
              double normalizedAngle = (angle + math.pi) / (2 * math.pi);
              setState(() {
                _currentSliderValue = normalizedAngle;
              });
            },
            child: Stack(
              children: [
                Center(
                  child: Text(
                    (_currentSliderValue * 100).toStringAsFixed(0) + '%',
                    style: TextStyle(fontSize: 20, color: Colors.white),
                  ),
                ),
                CustomPaint(
                  size: Size(200, 200),
                  painter: MyPainter(
                    progress: _currentSliderValue,
                    color: Colors.white,
                    width: 8,
                  ),
                ),
                Positioned(
                  left: 100 + 85 * math.cos(_currentSliderValue * 2 * math.pi - math.pi / 2),
                  top: 100 + 85 * math.sin(_currentSliderValue * 2 * math.pi - math.pi / 2),
                  child: Container(
                    width: 20,
                    height: 20,
                    decoration: BoxDecoration(
                      color: Colors.red,
                      shape: BoxShape.circle,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class MyPainter extends CustomPainter {
  final double progress;
  final Color color;
  final double width;

  MyPainter({required this.progress, required this.color, required this.width});

  @override
  void paint(Canvas canvas, Size size) {
    Paint paint = Paint()
      ..color = color
      ..strokeWidth = width
      ..strokeCap = StrokeCap.round
      ..style = PaintingStyle.stroke;

    canvas.drawArc(
        Rect.fromCircle(center: Offset(size.width / 2, size.height / 2), radius: size.width / 2),
        math.pi / 2,
        2 * math.pi * progress,
        false,
        paint);
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) {
    return true;
  }
}